package com.company;

public class WrapperEngine {

    private int power;

    public int getPower() {
        return power;
    }

    public WrapperEngine(int power) {
        this.power = power;
    }
}

package com.company;

import java.util.ArrayList;

public class HeatManager {
    private ArrayList<Integer> powers;

    public HeatManager(){
        this.powers = new ArrayList<>();
    }

    public ArrayList<Integer> getPower() {
        return this.powers;
    }

}

package com.company;

public class ProductionEngine {

    private int power;

    public int getPower() {
        return power;
    }

    public ProductionEngine(int power) {
        this.power = power;
    }
}

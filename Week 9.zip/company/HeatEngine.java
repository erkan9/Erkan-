package com.company;

public class HeatEngine {
    private int power;

    public int getPower() {
        return power;
    }

    public HeatEngine(int power) {
        this.power = power;
    }
}

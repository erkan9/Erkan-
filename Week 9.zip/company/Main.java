package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Person> people = new ArrayList<>();
        System.out.print("Въведи брой хора: ");
        int countOfPeople = scanner.nextInt();

        for (int i = 0; i < countOfPeople; i++) {

            System.out.print("Въведи сила на WrapperEngine: ");
            int wrapperEnginePower = scanner.nextInt();

            System.out.print("Въведи сила на ProductionEngine: ");
            int productionEnginePower = scanner.nextInt();

            System.out.print("Въведи сила на HeatEngine: ");
            int heatEnginePower = scanner.nextInt();

            WrapperEngine wrapperEngine = new WrapperEngine(wrapperEnginePower);
            ProductionEngine productionEngine = new ProductionEngine(productionEnginePower);
            HeatEngine heatEngine = new HeatEngine(heatEnginePower);

            double averagePowerOfEngine = (wrapperEngine.getPower()
                    + productionEngine.getPower() + heatEngine.getPower()) / 3.0;

            Engine engine = new Engine(averagePowerOfEngine);
            Machine machine = new Machine(engine);

            scanner.nextLine();
            System.out.print("Въведи име на човека: ");
            String name = scanner.nextLine();
            Person person = new Person(name,machine);

            HeatManager heatManager = new HeatManager();
            heatManager.getPower().add(heatEnginePower);
            heatManager.getPower().add(productionEnginePower);
            heatManager.getPower().add(wrapperEnginePower);
            person.setHeatManager(heatManager);

            people.add(person);
        }
        people.forEach(p ->{
            System.out.printf(p.getName() + " има машина със среден power: %.2f" +
                            ", HeatEngine: %d --- ProductionEngine: %d --- WrapperEngine: %d.%n"
                    , p.getMachine().getEngine().getPower()
                    , p.getHeatManager().getPower().get(0)
                    , p.getHeatManager().getPower().get(1)
                    , p.getHeatManager().getPower().get(2));
        });
    }
}
